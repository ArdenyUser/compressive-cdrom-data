#!/bin/bash

echo Booting Arden Play Zone...
sleep 2
echo Launching /LoadD/Programs/Games/arden-game-pl01.py...
sleep 5
clear
python /LoadD/Programs/Games/arden-game-pl01.py