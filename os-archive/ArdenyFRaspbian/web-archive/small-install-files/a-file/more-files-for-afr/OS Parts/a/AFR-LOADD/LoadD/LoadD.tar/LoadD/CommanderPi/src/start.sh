#!/bin/sh
sudo python3 ${HOME}/CommanderPi/src/main.py ${HOME}> commanderpi.log



