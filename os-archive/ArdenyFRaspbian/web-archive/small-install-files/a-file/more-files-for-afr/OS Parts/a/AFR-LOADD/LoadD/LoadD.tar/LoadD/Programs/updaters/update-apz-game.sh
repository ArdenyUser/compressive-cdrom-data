#!/bin/bash

sudo rm -dir /home/pi/arden-game-apz-main
sudo rm /LoadD/Programs/Games/arden-game-pl01.py
sudo wget https://github.com/ArdenyUser/arden-game-apz/archive/main.zip
sudo unzip /home/pi/Downloads/arden-game-apz-main.zip
sudo mv /home/pi/arden-game-apz-main/arden-game-pl01.py /LoadD/Programs/Games/
sudo mv /home/pi/main.zip /LoadD/Programs/Games
sudo unzip /LoadD/Programs/Games/main.zip
echo Sleeping for 3 seconds...
sleep 3
echo Performing cksum...
cksum /LoadD/Programs/Games/arden-game-pl01.py
echo Removing unused objects...
sudo rm /LoadD/Programs/Games/main.zip 
sudo rm -dir /home/pi/arden-game-apz-main