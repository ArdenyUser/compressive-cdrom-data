Installation
1. Move "CommanderPi" folder to "/home/user_name"
2. Make "sudo chmod +x install.sh"
3. Run "./install.sh"
4. Enjoy

!Overclocking and EEPROM change you do it at your own risk!

FAQ
- Q: Could I run this on Pi3?
- A: Yes, but all designed is for Pi4

- Q: I installed it like in readme and it's not working
- A: Check first: 
                  Is folder name is CommanderPi, not CommanderPi-master or something else
                  Is your path looks like /home/<user_name>/CommanderPi
                  Are you installed it without sudo? It wouldn't work if you install it with sudo!
                  
- Q: Is it works on Ubuntu?
- A: Yes, I added few things for compatibility but it depends on which version do you use
                  

All bugs please report here: https://github.com/Jack477/CommanderPi/issues

This app is part of TwisterOS project, please visit twisteros.com
