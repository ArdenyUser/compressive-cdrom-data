#!/bin/bash

chromium-browser https://www.netflix.com/