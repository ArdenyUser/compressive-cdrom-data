#Python Game 01

while True:
    print("Welcome to Arden Play Zone!")
    print("Exclusive to ArdenyFRaspbian OS!")
    print("")
    print("1: Shell 2: Begin 3: Info")
    x = input("@User: ")
    if x == "1":
        print("Error-use terminal emulater!")
    if x == "2":
        print("Feed Arden!")
        print("Type ENTER to feed her, to give her extra food, press 1.")
        input("@User: ")
        print("Yay, it did not matter.")
        print("Moving on...")
        input("@User: ")
        print('You pet Arden. THEN SHE RUNS AWAY!')
        input("@User: ")
        print("How do you find her?")
        print("1: Talk to people 2: Check your pocket for money 3: FBI")
        z = input("@FindHerNow: ")
        if z == "1":
            print("You still cant find her!")
            print('You check your pockett, "OH, there you are Arden!"')
        if z == "2":
            print('You check your pockett, "OH, there you are Arden!"')
        if z == "3":
            print("FBI OPEN UP!")
            input("")
            print("WE FOUND THE DOG, SEND IN THE HELICOPTER!")
            print("5 minutes later...")
            print("")
            print("You found her!")
