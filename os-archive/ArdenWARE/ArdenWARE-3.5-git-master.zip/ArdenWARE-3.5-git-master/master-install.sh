# Below is the unzip installer for the system.
# Below is very well needed.
sudo apt-get install unzip
# This will install main system features.
# This installs some stuff from the web.
# Please run this while os is running.
echo Broading master installion...
echo Echoing to web server...
# Above is the main informer, it is not needed.
# Below is the item installer, if you want, you can toy with it.
# Note: This installs items for ArdenWARE 2.2 not this os, which may cause issues.
wget https://github.com/ArdenyUser/ware3.5/archive/master.zip
unzip ware3.5-master.zip
mkdir SetUp
# This will also create a dir called SetUp.