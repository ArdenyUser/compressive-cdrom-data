# This ia a very high portible os, to open, run with terminal!
wget https://github.com/ArdenyUser/ware2.2/archive/master.zip
wget https://github.com/ArdenyUser/ArdenWARE-git-2.2/archive/master.zip